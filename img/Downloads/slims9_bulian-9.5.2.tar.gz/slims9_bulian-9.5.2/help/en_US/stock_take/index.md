#### Inventarisasi / Stock Take
<hr>
The Stock Take Module is a facility in SLiMS to help librarians conduct stock-taking. When the stock-taking process begins, all items except those being borrowed (status = on loan) will be marked as lost, and appear in the menu Current Lost Item until the item concerned is checked in the stock-take
