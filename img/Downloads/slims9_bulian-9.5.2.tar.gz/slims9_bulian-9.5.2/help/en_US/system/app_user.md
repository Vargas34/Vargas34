###System Users

A facility to determine which users can access the system, according to their permissions. These users will be able to perform a login according to their username and password respectively. This menu contains the options:

- Add New User (adding users), 
- Users List (list of users), 
- Search (search for a user), 
- Edit and Delete user. 

Within user information, user can also add their internet credentials, e.g. Facebook profile, blog or websites, etc.

To add a new user, click Add New User, and then fill in the Login Username, Real Name, Groups ( that they will belong to), and Password.
