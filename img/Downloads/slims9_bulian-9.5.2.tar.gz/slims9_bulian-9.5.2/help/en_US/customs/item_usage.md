###Item Usage

This is a report that lists the item, and how many times the copy has been borrowed on a monthly basis. Item usage also can be filtered by:
- Title/ISBN, 
- Item code, or 
- Year.
