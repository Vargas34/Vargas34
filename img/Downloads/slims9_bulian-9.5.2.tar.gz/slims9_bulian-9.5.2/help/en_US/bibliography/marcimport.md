#### Import MARC
<hr>
This feature is used to import MARC data files with either extension .MRC or .XML. Before using this feature, it's a condition that the SLiMS server has been installed with PEAR, FILE_MARC and Structures_LinkedList. On servers that use Ubuntu Linux, you can use the following command:
sudo pear install channel://pear.php.net/Structures_LinkedList-0.2.2  channel://pear.php.net/File_MARC-0.6.2

More about PEAR <a href = "http://pear.php.net/index.php" target="_blank">click here</a>, more about FILE_MARC, <a href = "http://pear.php.net/package/File_MARC" target="_blank">click here</a>, and Structures_LinkedList <a href = "http://pear.php.net/package/Structures_LinkedList" target="_blank">click here</a>
