#### Labels Printing Menu 
<hr>
With this menu you can print labels based on the collection of bibliographic data which is entered in SLiMS. The following sequence prints labels using Printing Labels menu:

- Click Labels Printing, and the display will appear as follows:
- Select the bibliography to print the label. Use Shift + click a checkbox to select more than one in rapid sequence. Note: one print run can only contain a maximum of 50 records. In this Print Label menu, it is possible to print more than one label, depending on how many copies of a title exist.
- Click Add to Print Queue to enter a selection in the print queue.
- Click Print to start printing the Selected Data, it will display a pop-up that asks you to send labels to the printer.
