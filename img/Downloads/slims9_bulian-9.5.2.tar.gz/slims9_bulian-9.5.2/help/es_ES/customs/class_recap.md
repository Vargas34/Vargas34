### Recapitulaciones personalizadas

Este menú muestra la recapitulación de:
- Títulos, basados en la clasificación,
- GMD,
- Tipo de colección o idioma.

Esta opción se puede ajustar seleccionando el filtro de recapitulación disponible. Senayan también admite la recapitulación de clasificaciones no estén basadas en números decimales. Por ejemplo, REF para referencias.

Recapitulación personalizada - "Imprimir página actual" brinda la posibilidad de imprimir los informes y "Exportar a formato de hoja de cálculo" para exportar el informe en una hoja de cálculo.
