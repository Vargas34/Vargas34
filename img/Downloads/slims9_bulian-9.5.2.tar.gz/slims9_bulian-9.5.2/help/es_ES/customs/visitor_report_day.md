###Estadística de visitantes (por día)

Este es un informe basado en el número de visitantes por cada día de la semana.