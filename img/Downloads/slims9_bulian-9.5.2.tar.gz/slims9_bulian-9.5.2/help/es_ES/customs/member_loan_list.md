###Lista de préstamos por miembro

Este es un informe que contiene una lista de los ejemplares que aún están prestados por los miembros.

