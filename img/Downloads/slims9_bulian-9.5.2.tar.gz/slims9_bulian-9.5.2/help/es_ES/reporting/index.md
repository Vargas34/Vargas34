###Estadística de la colección

Contiene la información total de la colección para:
- Iítulos,
- Total de ejemplares,
- Total de ejemplares prestados,
- Total de ejemplares que están en la biblioteca (no prestados),
- Total de títulos basados en la DGM,
- Total de ejemplares de la colección por tipo, y
- Los diez (10) títulos más populares (los más prestados).