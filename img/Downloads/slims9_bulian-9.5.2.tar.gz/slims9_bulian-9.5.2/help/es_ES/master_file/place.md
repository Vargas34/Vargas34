#### Archivo maestro / Lugar de publicación
<hr>
Contiene el lugar de publicación.
Por ejemplo: Jakarta, Londres, etc.