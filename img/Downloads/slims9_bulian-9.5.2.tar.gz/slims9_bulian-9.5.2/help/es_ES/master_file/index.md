#### Archivo maestro / GMD
<hr>
En este módulo podemos ingresar los datos del archivo maestro que se pueden utilizar como la base principal en la entrada de los datos bibliográficos.
- Designación General del Material (GMD) - La forma física de la obra a catalogar.