#### Archivo maestro / Tipo de colección
<hr>
El tipo de colección de los ejemplares que posee la biblioteca, por ejemplo: Libros de texto, Referencias, etc.