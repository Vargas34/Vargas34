#### Archivo maestro / Frecuencia
<hr>
La frecuencia de publicación de las publicaciones seriadas.